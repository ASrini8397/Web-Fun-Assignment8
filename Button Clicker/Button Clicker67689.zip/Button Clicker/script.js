var click= document.querySelector(".btn")
function Clicked(liked){
    click.innerText="Logout"

}
 
function Def(){
    var remove = document.querySelector(".Definition")
    remove.parentNode.removeChild(remove);
}